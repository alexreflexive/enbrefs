<?php
require_once('classes/mysql.class.php');  
require_once('constants.php') ;
require_once('config.php') ;
require_once('functions/controlfunctions.php');
require_once('classes/html.class.php');  
require_once('functions/functions.php') ;
//require_once('recherches.php') ;
/*
require_once('classes/nav.html.class.php');
*/

